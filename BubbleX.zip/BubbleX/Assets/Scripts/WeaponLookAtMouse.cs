﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponLookAtMouse : MonoBehaviour
{
    [SerializeField]
    float mouseSensitivity;

    float xAxisClamp;

    [SerializeField]
    Transform player,weapon;

    void Update()
    {
        Cursor.lockState = CursorLockMode.Locked;
        RotateCamera();
    }

    // Update is called once per frame
    void RotateCamera()
    {
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        Vector3 rotWeapon = weapon.transform.rotation.eulerAngles;
        Vector3 rotPlayer = player.transform.rotation.eulerAngles;

        

        float rotAmountX = mouseX * mouseSensitivity;
        float rotAmountY = mouseY * mouseSensitivity;

        xAxisClamp -= rotAmountY;

        rotWeapon.x -= rotAmountY;
        rotWeapon.z = 0;
        rotPlayer.y += rotAmountX;

        if (xAxisClamp >90)
        {
            xAxisClamp = 90;
            rotWeapon.x = 90;
        }else if (xAxisClamp  <-90)
        {
            xAxisClamp = -90;
            rotWeapon.x = 270;
        }

        weapon.rotation = Quaternion.Euler(rotWeapon);
        player.rotation = Quaternion.Euler(rotPlayer);
    }
}

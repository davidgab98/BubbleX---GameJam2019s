using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    //Variable estatica
    public static GameController instance; //Para acceder desde cualquier clase a esta clase GameController

    //Matriz de columnas
    public Columna[,] columnaMatrix;
    public InfoCasilla[,] infoCasillaMatrix;
    public int tamtablero;

    //Variables de gameOver
    public bool gameOver;

    //Variables de tiempo
    public float tiempoMaximo;    
    public float contadorTiempo;  
        
    private void Awake()
    {
        //Inicializacion de la matriz de columnas
        columnaMatrix = new Columna[tamtablero, tamtablero];
        infoCasillaMatrix = new InfoCasilla[tamtablero, tamtablero];

        //Mierdas para la varible estatica
        if (GameController.instance == null)
        {
            GameController.instance = this;

        }
        else
        {
            Destroy(gameObject);
            Debug.LogWarning("GameController ha sido instanciado por segunda vez. Esto no debería pasar");
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        tiempoMaximo = 300; //5 minutos
        contadorTiempo = 0;

        CrearMatrizInfoCasillas(); 
    }

    // Update is called once per frame
    void Update()
    {
        contadorTiempo += Time.deltaTime;
        if(contadorTiempo >= tiempoMaximo)
        {
            gameOver = true; 
        }
    }
    

    private void CrearMatrizInfoCasillas()
    {
        int contadorPosX = -tamtablero/2;
        int contadorPosY = tamtablero/2;
        for(int i = 0; i < tamtablero; i++)
        {
            for(int j = 0; j < tamtablero; j++)
            {
                infoCasillaMatrix[i, j] = new InfoCasilla();
                infoCasillaMatrix[i, j].SetPosicion(new Vector2(contadorPosX, contadorPosY));

                contadorPosX++;
            }
            contadorPosX = -tamtablero / 2;
            contadorPosY--;
        }
    }

    public void AsignarNivelesAMatrizInfoCasillas()
    {

    }


    private void OnDestroy()
    {
        if (GameController.instance == this)
        {
            GameController.instance = null;
        }
    }
}

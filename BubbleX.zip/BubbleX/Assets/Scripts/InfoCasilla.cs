using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoCasilla : MonoBehaviour
{
    Vector2 posicion;
    public int nivel;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetPosicion(Vector2 pos)
    {
        posicion = pos;
    }

    public Vector2 GetPosicion()
    {
        return posicion;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Columna : MonoBehaviour
{
    public Material material;
    public Vector2 posicion;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Aparecer(Material m, Vector2 pos)
    {
        material = m;
        posicion = pos;
    }
}

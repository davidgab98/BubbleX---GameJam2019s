using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlCamaras : MonoBehaviour
{
    public Camera firstPersonCam;
    public Camera aerealCam;

    // Start is called before the first frame update
    void Start()
    {
        firstPersonCam.gameObject.SetActive(true);
        aerealCam.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            firstPersonCam.gameObject.SetActive(false);
            aerealCam.gameObject.SetActive(true);
        }
        else if (Input.GetKeyUp(KeyCode.LeftControl))
        {
            firstPersonCam.gameObject.SetActive(true);
            aerealCam.gameObject.SetActive(false);
        }
            
    }
}
